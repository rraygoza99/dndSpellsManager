﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BL.BusinessLogic
{
    public class Constants
    {
        public Constants()
        {

        }
        
    }
}
