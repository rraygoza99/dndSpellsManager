﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BL.BusinessLogic.ViewModel
{
    public class SpellSpellbookViewModel
    {
        public int IdSpellbook { get; set; }
        public int IdSpell { get; set; }
    }
}
